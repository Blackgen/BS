/*
 * getch.h
 *
 *  Created on: 03.11.2014
 *      Author: torbenhaug
 */

#ifndef GETCH_H_
#define GETCH_H_
	#include <termios.h>
	#include <stdio.h>
	char getchi(void);
	char getche(void);

#endif /* GETCH_H_ */
