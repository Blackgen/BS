/*
 * consumer.h
 *
 *  Created on: 14.10.2014
 *      Author: torbenhaug
 * Include this file for using consumer
 */

#ifndef CONSUMER_H_
#define CONSUMER_H_
	#include "rb.h"
	void* consumer(void *pid);
#endif // CONSUMER_H_
