/*
 * producer.h
 *
 *  Created on: 29.10.2014
 *      Author: torbenhaug
 */

#ifndef PRODUCER_H_
#define PRODUCER_H_
	#include "rb.h"

#endif // PRODUCER_H_
