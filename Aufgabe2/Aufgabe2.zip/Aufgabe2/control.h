
#ifndef CONTROL_H_
#define CONTROL_H_
	#include "rb.h"
	#include "getch.h"
	void* control(void *pid);
	void usage();
#endif // CONTROL_H_
