/*
 * main.h
 *
 *  Created on: 02.11.2014
 *      Author: torbenhaug
 */

#ifndef MAIN_H_
#define MAIN_H_
	#include "rb.h"
	int main(int argc, char* argv[]);

#endif /* MAIN_H_ */
